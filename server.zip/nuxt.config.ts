export default defineNuxtConfig({
  ssr: true,
  css: ["~/assets/styles/main.scss", "./assets/styles/css/tailwind.css"],
  compatibilityDate: "2024-11-01",
  devtools: { enabled: true },
  modules: ["@nuxtjs/tailwindcss", "@nuxt/icon", "nuxt-aos", "@vite-pwa/nuxt"],
});